﻿using Microsoft.AspNetCore.Mvc;
using ShopProject.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using ShopProject.Models.Shop;
using Microsoft.AspNetCore.Http;



namespace ShopProject.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        private readonly ShopDbContext _context;
        public CartController(ShopDbContext context)
        {
            _context = context;
        }
        

        public IActionResult CartIndex()
        {

            
            var userId = User.FindFirst(ClaimTypes.Sid).Value;
            var itemlist = _context.Carts.Where(x => x.UserId == userId).ToList();
            if(itemlist.Count == 0)
            {
                ViewData["Error"] = "查無購物車資料";
                return View();

            }
            return View(itemlist);
        }

        //AddtoCart還沒完成，問題點在，不知道要怎麼把使用者想加入購物車的商品型號接過來用=>已解決，使用asp-route-{value},詳細筆記如下:

        //AddtoCart括號裡的參數，指的是從View那邊傳過來的資料，這邊因為要比對商品的Model所以寫入string Model
        //對應的code是在商品頁面，購物車的<a>連結裡面寫的asp-route-model[{value}]="@item.Model"








        public IActionResult AddtoCart(string model,string name,int price,int amount,string imgurl)
        {
            
            var userId = User.FindFirst(ClaimTypes.Sid).Value;
            var itemList = _context.Carts.Where(x=> x.Model == model && x.UserId == userId).ToList();
            var item = itemList.FirstOrDefault();
            


            if (item != null)
            {
                item.Amount += amount  ;
                _context.Update(item); //這邊要使用Update去更新購物車裡同樣商品的數量
                _context.SaveChanges(); //記得更改完之後要SaveChange，不然會寫不進資料庫

            }
            else
            {
                var newitem = new Cart()
                {

                    Name = name,
                    Model = model,
                    Price = price,
                    Amount = amount,
                    ImgUrl = imgurl,
                    UserId = userId
                };

                _context.Carts.Add(newitem);
                _context.SaveChanges();
            }
            string itemcount = _context.Carts.Where(x => x.UserId == userId).Select(x => x.Amount).Sum().ToString();

            HttpContext.Session.SetString("AmountItem", itemcount);
            //這個購物車數量要在顯示時判斷使用者是否登入，登入成功才會顯示並去撈使用者在購物車資料表的產品數量總數
            return Redirect(Request.Headers["Referer"].ToString()); //這邊要再查一下資料，我其實看不懂是複製的
        }

        public IActionResult DeleteItem(string model)
        {
            var userId = User.FindFirst(ClaimTypes.Sid).Value;
            var itemList = _context.Carts.Where(x => x.Model == model && x.UserId == userId).ToList();
            var item = itemList.FirstOrDefault();
            _context.Remove(item);
            _context.SaveChanges();
            string itemcount = _context.Carts.Where(x => x.UserId == userId).Select(x => x.Amount).Sum().ToString();

            HttpContext.Session.SetString("AmountItem", itemcount);
            return Redirect(Request.Headers["Referer"].ToString());


        }
        




    }
}

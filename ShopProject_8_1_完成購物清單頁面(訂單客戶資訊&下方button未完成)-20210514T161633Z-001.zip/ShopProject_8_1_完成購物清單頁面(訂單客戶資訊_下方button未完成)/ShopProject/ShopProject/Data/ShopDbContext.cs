﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using ShopProject.Models.Shop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopProject.Data
{
    public class ShopDbContext : DbContext
    {
        public ShopDbContext()
        {
        }

        public ShopDbContext(DbContextOptions<ShopDbContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Purchase> Purchases { get; set; }

        public DbSet<ProductType> productTypes { get; set; }

        public DbSet<Cart> Carts { get; set; }



        /*protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=ShopProjectDb;Trusted_Connection=True;Integrated Security=true;");
            base.OnConfiguring(optionsBuilder);

        }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(

               new Product { Id = 1, Name = "白色上衣外套", Model = "T001", Price = 900, ImgUrl = "~/images/clothes/clothes1.jpg", TypeId = 1, CreationDate = DateTime.Now },
               new Product { Id = 2, Name = "白色短版背心", Model = "T002",  Price = 500, ImgUrl = "~/images/clothes/clothes2.jpg", TypeId = 1, CreationDate = DateTime.Now },
               new Product { Id = 3, Name = "白色蕾絲背心", Model = "T003", Price = 500, ImgUrl = "~/images/clothes/clothes3.jpg", TypeId = 1, CreationDate = DateTime.Now },
               new Product { Id = 4, Name = "杏色無袖背心", Model = "T004",  Price = 700, ImgUrl = "~/images/clothes/clothes4.jpg", TypeId = 1, CreationDate = DateTime.Now },
               new Product { Id = 5, Name = "灰色花邊寬褲", Model = "T005",  Price = 1200, ImgUrl = "~/images/bottom/bottom1.jpg", TypeId = 2, CreationDate = DateTime.Now },
               new Product { Id = 6, Name = "黑色緞面喇叭褲", Model = "T006",  Price = 1200, ImgUrl = "~/images/bottom/bottom2.jpg", TypeId = 2, CreationDate = DateTime.Now },
               new Product { Id = 7, Name = "格紋長褲", Model = "T007",  Price = 1100, ImgUrl = "~/images/bottom/bottom3.jpg", TypeId = 2, CreationDate = DateTime.Now },
               new Product { Id = 8, Name = "變形蟲短裙", Model = "T008",  Price = 1200, ImgUrl = "~/images/bottom/bottom4.jpg", TypeId = 2, CreationDate = DateTime.Now },
               new Product { Id = 9, Name = "紅色高跟鞋", Model = "T009",  Price = 900, ImgUrl = "~/images/shoes/shoes1.jpg", TypeId = 3, CreationDate = DateTime.Now },
               new Product { Id = 10, Name = "白色高跟鞋", Model = "T010",  Price = 900, ImgUrl = "~/images/shoes/shoes2.jpg", TypeId = 3, CreationDate = DateTime.Now },
               new Product { Id = 11, Name = "綠色高跟鞋", Model = "T011",  Price = 900, ImgUrl = "~/images/shoes/shoes3.jpg", TypeId = 3, CreationDate = DateTime.Now },
               new Product { Id = 12, Name = "白色運動鞋", Model = "T012",  Price = 900, ImgUrl = "~/images/shoes/shoes4.jpg", TypeId = 3, CreationDate = DateTime.Now },
               new Product { Id = 13, Name = "金色復古手錶", Model = "T013",  Price = 600, ImgUrl = "~/images/accessories/accessories1.jpg", TypeId = 4, CreationDate = DateTime.Now },
               new Product { Id = 14, Name = "藍色流蘇耳環", Model = "T014",  Price = 500, ImgUrl = "~/images/accessories/accessories2.jpg", TypeId = 4, CreationDate = DateTime.Now },
               new Product { Id = 15, Name = "黑色手提小包", Model = "T015",  Price = 800, ImgUrl = "~/images/accessories/accessories3.jpg", TypeId = 4, CreationDate = DateTime.Now },
               new Product { Id = 16, Name = "復古風眼鏡", Model = "T016",  Price = 800, ImgUrl = "~/images/accessories/accessories4.jpg", TypeId = 4, CreationDate = DateTime.Now }

               );

            modelBuilder.Entity<Customer>().HasData(

                new Customer { Id = 1, Name = "Admin", Email = "Admin@gmail.com", Password = "123", Admin = true, Birthday = DateTime.Now },
                new Customer { Id = 2, Name = "User", Email = "User@gmail.com", Password = "123", Admin = false, Birthday = DateTime.Now }
                );


            modelBuilder.Entity<ProductType>().HasData(

                new ProductType { Id = 1, Name="Top"  },
                new ProductType { Id = 2, Name = "Bottom" },
                new ProductType { Id = 3, Name = "Shoes" },
                new ProductType { Id = 4, Name = "Accessories" }
                );







        }
        }
    }


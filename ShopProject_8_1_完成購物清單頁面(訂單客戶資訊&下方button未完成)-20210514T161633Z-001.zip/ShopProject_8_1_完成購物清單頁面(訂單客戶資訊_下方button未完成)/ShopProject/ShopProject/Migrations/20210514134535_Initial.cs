﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ShopProject.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Carts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Model = table.Column<string>(nullable: true),
                    Price = table.Column<int>(nullable: false),
                    Amount = table.Column<int>(nullable: false),
                    ImgUrl = table.Column<string>(nullable: true),
                    UserId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Carts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: false),
                    Password = table.Column<string>(nullable: false),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    Birthday = table.Column<DateTime>(nullable: false),
                    Admin = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "productTypes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_productTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Purchases",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    UpdateDate = table.Column<DateTime>(nullable: false),
                    TotalPrice = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Purchases", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Purchases_Customers_UserId",
                        column: x => x.UserId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Model = table.Column<string>(nullable: true),
                    Price = table.Column<int>(nullable: false),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    TypeId = table.Column<int>(nullable: false),
                    ImgUrl = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_productTypes_TypeId",
                        column: x => x.TypeId,
                        principalTable: "productTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PurchaseId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Amount = table.Column<int>(nullable: false),
                    Price = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orders_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Orders_Purchases_PurchaseId",
                        column: x => x.PurchaseId,
                        principalTable: "Purchases",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Id", "Address", "Admin", "Birthday", "Email", "Name", "Password", "Phone" },
                values: new object[,]
                {
                    { 1, null, true, new DateTime(2021, 5, 14, 21, 45, 35, 358, DateTimeKind.Local).AddTicks(4182), "Admin@gmail.com", "Admin", "123", null },
                    { 2, null, false, new DateTime(2021, 5, 14, 21, 45, 35, 358, DateTimeKind.Local).AddTicks(4672), "User@gmail.com", "User", "123", null }
                });

            migrationBuilder.InsertData(
                table: "productTypes",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Top" },
                    { 2, "Bottom" },
                    { 3, "Shoes" },
                    { 4, "Accessories" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CreationDate", "ImgUrl", "Model", "Name", "Price", "TypeId" },
                values: new object[,]
                {
                    { 1, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(2241), "~/images/clothes/clothes1.jpg", "T001", "白色上衣外套", 900, 1 },
                    { 2, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9899), "~/images/clothes/clothes2.jpg", "T002", "白色短版背心", 500, 1 },
                    { 3, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9921), "~/images/clothes/clothes3.jpg", "T003", "白色蕾絲背心", 500, 1 },
                    { 4, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9924), "~/images/clothes/clothes4.jpg", "T004", "杏色無袖背心", 700, 1 },
                    { 5, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9926), "~/images/bottom/bottom1.jpg", "T005", "灰色花邊寬褲", 1200, 2 },
                    { 6, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9928), "~/images/bottom/bottom2.jpg", "T006", "黑色緞面喇叭褲", 1200, 2 },
                    { 7, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9930), "~/images/bottom/bottom3.jpg", "T007", "格紋長褲", 1100, 2 },
                    { 8, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9931), "~/images/bottom/bottom4.jpg", "T008", "變形蟲短裙", 1200, 2 },
                    { 9, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9933), "~/images/shoes/shoes1.jpg", "T009", "紅色高跟鞋", 900, 3 },
                    { 10, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9935), "~/images/shoes/shoes2.jpg", "T010", "白色高跟鞋", 900, 3 },
                    { 11, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9937), "~/images/shoes/shoes3.jpg", "T011", "綠色高跟鞋", 900, 3 },
                    { 12, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9939), "~/images/shoes/shoes4.jpg", "T012", "白色運動鞋", 900, 3 },
                    { 13, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9941), "~/images/accessories/accessories1.jpg", "T013", "金色復古手錶", 600, 4 },
                    { 14, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9943), "~/images/accessories/accessories2.jpg", "T014", "藍色流蘇耳環", 500, 4 },
                    { 15, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9988), "~/images/accessories/accessories3.jpg", "T015", "黑色手提小包", 800, 4 },
                    { 16, new DateTime(2021, 5, 14, 21, 45, 35, 356, DateTimeKind.Local).AddTicks(9990), "~/images/accessories/accessories4.jpg", "T016", "復古風眼鏡", 800, 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ProductId",
                table: "Orders",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_PurchaseId",
                table: "Orders",
                column: "PurchaseId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_TypeId",
                table: "Products",
                column: "TypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Purchases_UserId",
                table: "Purchases",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Carts");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Purchases");

            migrationBuilder.DropTable(
                name: "productTypes");

            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
